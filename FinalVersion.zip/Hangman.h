#ifndef _HANGMAN_H_
#define _HANGMAN_H_
#include <iostream>
#include <fstream>
#include <ctime>
#include <string>

using namespace std;

class Hangman
{	
public:
	//

};

#endif